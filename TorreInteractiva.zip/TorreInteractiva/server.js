const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const osc = require('osc');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Configuración de OSC para enviar a TouchDesigner (Puerto 3333 local)
const udpPort = new osc.UDPPort({
    localAddress: "0.0.0.0",
    localPort: 57121,
    remoteAddress: "127.0.0.1",
    remotePort: 3333 
});
udpPort.open();

app.use(express.static('public'));

// Variables del juego
let clicsEnEstaRonda = 0;
let jugadoresConectados = 0;

io.on('connection', (socket) => {
    jugadoresConectados++;
    console.log(`Cliente conectado. Total en la sala: ${jugadoresConectados}`);

    // Escuchamos cuando los teléfonos presionan el botón
    socket.on('boton_presionado', () => {
        clicsEnEstaRonda++;
        
        // Si la mitad o más de los conectados presiona, enviamos la orden de corte a la pantalla
        if (clicsEnEstaRonda >= (jugadoresConectados / 2)) {
            io.emit('orden_corte');
            clicsEnEstaRonda = 0;
        }
    });

    // Escuchamos los datos del bloque que envía pantalla.html para reenviarlos a TouchDesigner por OSC
    socket.on('datos_para_td', (datos) => {
        console.log("Enviando a TouchDesigner:", datos);
        udpPort.send({
            address: "/juego/bloque",
            args: [
                { type: "i", value: datos.nivel },
                { type: "f", value: datos.velocidad },
                { type: "f", value: datos.ancho },
                { type: "f", value: datos.posX }
            ]
        });
    });

    // Cuando la pantalla del PC se recarga, notificamos a TouchDesigner para limpiar la torre 3D
    socket.on('reiniciar_juego', () => {
        console.log("Juego reiniciado desde el navegador. Notificando a TouchDesigner...");
        clicsEnEstaRonda = 0;

        // Pulso inicial (-1) para forzar la actualización de la señal CHOP en TouchDesigner
        udpPort.send({
            address: "/juego/bloque",
            args: [
                { type: "i", value: -1 },
                { type: "f", value: 1.0 },
                { type: "f", value: 200 },
                { type: "f", value: 200 }
            ]
        });

        // Confirmación de nivel 0
        setTimeout(() => {
            udpPort.send({
                address: "/juego/bloque",
                args: [
                    { type: "i", value: 0 },
                    { type: "f", value: 1.0 },
                    { type: "f", value: 200 },
                    { type: "f", value: 200 }
                ]
            });
        }, 50);
    });

    socket.on('disconnect', () => {
        jugadoresConectados--;
        if (jugadoresConectados < 0) jugadoresConectados = 0;
        console.log(`Cliente desconectado. Total en la sala: ${jugadoresConectados}`);
    });
});

const PUERTO = 3000;
server.listen(PUERTO, () => {
    console.log(`Servidor corriendo. Abre en la pantalla del PC: http://localhost:${PUERTO}/pantalla.html`);
});